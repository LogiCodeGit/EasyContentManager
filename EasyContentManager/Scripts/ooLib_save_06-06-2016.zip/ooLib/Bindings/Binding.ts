﻿/**
 * Binding module
*/

/// <reference path="../../typings/requirejs/require.d.ts" />
//import "ooLib/BaseObjects"      // !! sostituito con require (rimappato in requireModules.js) perchè da problemi con intellisense e compilazione
//require("ooLib/BaseObjects");

// Intellisense and import (pair/s) for required modules:
/// <reference path="../../typings/jquery/jquery.d.ts" />
//
/// <reference path="../BaseObjects.ts"/>
//** <amd-dependency path="ooLib/BaseObjects"/>

//import * as _oo from '../BaseObjects';
//import '../BaseObjects';
//
// AngularJS Binding with Typescript
// https://docs.angularjs.org/api
// http://www.html.it/pag/52588/angularjs-e-un-framework-non-una-libreria/
// http://docs.telerik.com/kendo-ui/AngularJS/introduction
/// <reference path="../../typings/angularjs/angular.d.ts"/>

// .. test import, need follow parameters in tsconfig.json
//        "module": "amd",
//        "args": ["--module"],
//import {angular} from '../../typings/angularjs/angular.d.ts';
// 
// For module import/export see:
// http://www.typescriptlang.org/docs/handbook/modules.html

//declare module '_oo-Bindings' {
//    var _: string;
//    export = _;
//}

//export namespace ooLib {
//    export module Bindings {
//        //var _: string;
//        //export = _;
//    }
//}
// Define shortcut alias and imports
//import * from '../Global.ts';
//import {_oo} from "../BaseObjects";
//require("ooLib/BaseObjects");
//import ooLib = require('ooLib/BaseObjects');
//import 'ooLib/BaseObjects';
import {BaseObjects} from 'ooLib/BaseObjects'

//namespace ooLib {

    export namespace Bindings {

        // Define shortcut alias and imports
        //import * from '../Global.ts';
        //import _objs = ooLib.BaseObjects;

        //import _angular = module('../../typings/angularjs/angular.d.ts');
        //var $: JQueryStatic = JQuery.$;

        export class DataBinding extends BaseObjects.Binding {
            private _viewID: string;
            // Use Angular module for this implementation
            private _ngModule: ng.IModule;
            //
            /**
             * DataBinding constructor
             * @param {string} viewID identify the view container of the controls to be bind (for AngularJS is the ng-app attribute)
             * @param {string[]} modules can specify the optional modules (for AngularJS see 2nd parameter of angular.module, http://www.html.it/pag/53891/i-moduli-angularjs/)
             * @param {Function} configFn can specify optional function for configuration (for AngularJS see 3th parameter of angular.module)
             */
            constructor(viewID: string,
                modules?: string[],
                configFn?: Function,
                description?: string) {
                super(description);
                this._viewID = viewID;
                this._ngModule = angular.module(viewID, modules, configFn);
            };

            /**
             * @description Add new data binding connection for view control (by id) and data (or its path)
             * @param {string} ctrlID identify the control in the view (for AngularJS is the ng-model attribute), or id of DOM element if forceNativeIDForEvent is set
             * @param {any} data data variable or data object
             * @param {string} path optional internal data path if the data parameter is an object
             * @param {string} forceNativeIDForEvent optional DOM event for custom binding (see jquery .on()), in this case ctrlID must be the id of DOM element
             */
            addBind(ctrlID: string,
                data: any,
                path?: string,
                forceNativeIDForEvent?: string): void {

                // Activate the angular controller for the data
                this._ngModule.controller(ctrlID).run(function (scope: ng.IScope) {       // can implement also the filter parameter and others, see http://www.html.it/pag/53418/filtri-nel-controller/ and http://www.html.it/pag/54118/configurazione-del-routing/

                    // Initialize the data scope (two-way binding by angular managed event and internal digest loop)
                    // http://www.html.it/pag/54317/watch-e-digest-loop/
                    scope[ctrlID] = (path ? data[path] : data);

                    // Activate optional behavior for native DOM event or data object
                    if (forceNativeIDForEvent) {
                        // Set native event with DOM element id
                        // http://www.html.it/pag/54402/apply-e-il-contesto-angular/
                        var ctrl: JQuery = $("#" + ctrlID);
                        ctrl.on(forceNativeIDForEvent, function (evt: JQueryEventObject, ...args: any[]) {
                            //document.getElementById(ctrlID).addEventListener(forceNativeIDForEvent, function () {
                            scope.$apply(function (scope: ng.IScope) {
                                scope[ctrlID] = (path ? data[path] : data);
                            });
                        });
                    }
                    //
                    if (!path && typeof data == "object") {
                        // Bind changes of entire object
                        // http://www.html.it/pag/54404/creare-un-watch-in-angularjs/
                        scope.$watch(ctrlID, function (newValue: string, oldValue: string) {
                            if (newValue != oldValue)
                                alert("Il nuovo valore è " + newValue);
                        }, true);
                    }
                });
            }
        }
    }
//}


    //namespace ooLib {
    //    export module Bindings { }
    //}

//declare module Binding {
//    interface IModule {
//    }
//}
